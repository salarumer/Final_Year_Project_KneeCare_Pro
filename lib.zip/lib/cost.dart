const String Gemini_Api_Key = "AIzaSyDsrl9MACRkA-cvaz8HL8_8gUj7UBIb4eY";

const String googleMapsApiKey = "AIzaSyA7JHJ5ZMv7VtGmK1BRNIPv5Q90iJhQt-M";
