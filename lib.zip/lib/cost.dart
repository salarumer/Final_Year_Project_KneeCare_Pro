const String Gemini_Api_Key = "gemini_api";

const String googleMapsApiKey = "googlemaps_api";
